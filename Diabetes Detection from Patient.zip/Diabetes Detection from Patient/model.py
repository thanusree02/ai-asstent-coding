# model.py
import pickle
import numpy as np

_model = None
try:
    _model = pickle.load(open("model.pkl","rb"))
except Exception:
    _model = None

def predict(X):
    """
    X: array-like 2D
    Returns 0 or 1
    """
    if _model is None:
        # fallback: simple threshold on Glucose
        X = np.asarray(X)
        return np.where(X[:,1] >= 140, 1, 0)
    else:
        return _model.predict(X)

