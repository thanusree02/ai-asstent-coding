from flask import Flask, render_template, request, redirect, url_for, flash
import os
import numpy as np

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET", "dev-secret-key")

# Try to import your model from model.py (optional). model.py should expose a `predict` function
# that accepts a 2D array-like and returns 0/1 or a label string.
try:
    import model  # user-provided file that should contain a predict(array) function
    has_model = True
except Exception:
    has_model = False

def make_prediction(features):
    """
    features: list/array of length 8 in the order:
    [Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin, BMI, DiabetesPedigreeFunction, Age]
    Returns a string to display to user.
    """
    arr = np.array(features, dtype=float).reshape(1, -1)
    if has_model and hasattr(model, "predict"):
        try:
            pred = model.predict(arr)
            # normalize output to a string
            if isinstance(pred, (list, tuple, np.ndarray)):
                pred = pred[0]
            if str(pred) in ("0", 0):
                return "NOT Diabetic (model prediction: 0)"
            elif str(pred) in ("1", 1):
                return "Diabetic (model prediction: 1)"
            else:
                return f"Model output: {pred}"
        except Exception as e:
            return f"Model error: {e}"
    else:
        # fallback heuristic / dummy decision: (simple threshold on Glucose)
        glucose = float(arr[0,1])
        if glucose >= 140:
            return "Diabetic (fallback heuristic: glucose >= 140)"
        else:
            return "NOT Diabetic (fallback heuristic: glucose < 140)"

@app.route("/", methods=["GET"])
def home():
    return render_template("home.html")

@app.route("/form", methods=["POST"])
def form_to_predict():
    # collect patient details submitted from home page and render prediction page
    patient = {
        "name": request.form.get("name","").strip(),
        "patient_id": request.form.get("patient_id","").strip(),
        "gender": request.form.get("gender","").strip(),
        "dob": request.form.get("dob","").strip(),
        "contact": request.form.get("contact","").strip(),
        "notes": request.form.get("notes","").strip()
    }
    return render_template("predict.html", patient=patient)

@app.route("/predict", methods=["POST"])
def predict():
    # patient details may be included as hidden inputs
    patient = {
        "name": request.form.get("name","").strip(),
        "patient_id": request.form.get("patient_id","").strip(),
        "gender": request.form.get("gender","").strip(),
        "dob": request.form.get("dob","").strip(),
        "contact": request.form.get("contact","").strip(),
        "notes": request.form.get("notes","").strip()
    }

    try:
        # parse numeric fields
        fields = [
            float(request.form["Pregnancies"]),
            float(request.form["Glucose"]),
            float(request.form["BloodPressure"]),
            float(request.form["SkinThickness"]),
            float(request.form["Insulin"]),
            float(request.form["BMI"]),
            float(request.form["DiabetesPedigreeFunction"]),
            float(request.form["Age"])
        ]
    except Exception as e:
        flash("Please enter valid numeric values for all measurement fields.")
        return render_template("predict.html", patient=patient)

    # produce prediction using model fallback
    result = make_prediction(fields)
    return render_template("predict.html", patient=patient, result=result)

if __name__ == "__main__":
    app.run(debug=True)
